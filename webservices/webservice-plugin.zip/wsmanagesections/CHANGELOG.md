# Changelog

## 2020-07-27 (v.0.9.6)
- rearranged function according to the example of the core_course functions
- update is now possible für additional settings: summary, visibility, highlight, ...
- added a function to delete sections

## 2020-07-25
- added two functions:
  - get_sectionnames
  - get_sectionformatoptions
- reduced database requests in update_sectionnames and update_sectionsformatoptions
## 2020-07-21

- Initial release
